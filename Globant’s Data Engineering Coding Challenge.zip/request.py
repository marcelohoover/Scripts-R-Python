
import requests
import os

def insert_emps():
    # URL API
    url = 'http://127.0.0.1:5000/upload_emp'

    #headers = {"Content-Type": "application/json; charset=utf-8"}

    file_path = 'hired_employees.csv'

    # Send POST request csv file
    with open(file_path, 'rb') as f:
        files = {'file': f}
        response = requests.post(url, files=files)
        #response = requests.post(url, headers=headers, files={'file': f})
        
    # Check API response
    if response.status_code == 200:
        print('Employees data inserted successfully!')
    else:
        print(f'Failed to insert data: {response.status_code} - {response.text}')  
    
    print("JSON Response ", response.json())


def insert_jobs():
    url = 'http://127.0.0.1:5000/upload_job'

    #headers = {"Content-Type": "application/json; charset=utf-8"}

    file_path = 'jobs.csv'

    # Send POST request csv file
    with open(file_path, 'rb') as f:
        files = {'file': f}
        response = requests.post(url, files=files)
        #response = requests.post(url, headers=headers, files={'file': f})
        
    # Check API response
    if response.status_code == 200:
        print('Jobs data inserted successfully!')
    else:
        print(f'Failed to insert data: {response.status_code} - {response.text}')  
    
    print("JSON Response ", response.json())


def insert_deps():
    url = 'http://127.0.0.1:5000/upload_dep'

    #headers = {"Content-Type": "application/json; charset=utf-8"}

    file_path = 'departments.csv'

    # Send POST request csv file
    with open(file_path, 'rb') as f:
        files = {'file': f}
        response = requests.post(url, files=files)
        #response = requests.post(url, headers=headers, files={'file': f})
        
    # Check API response
    if response.status_code == 200:
        print('Departments data inserted successfully!')
    else:
        print(f'Failed to insert data: {response.status_code} - {response.text}')  
    
    print("JSON Response ", response.json())


if __name__ == "__main__":

    #os.getcwd()
    try:
        insert_emps()
    except:
        print(f'Failed to ingest Employees file') 
    
    try:    
        insert_jobs()
    except:
        print(f'Failed to ingest Departments file') 
        
    try:
        insert_deps() 
    except:
        print(f'Failed to ingest Jobs file') 
    

import os
import pandas as pd
import sqlite3

#!pip install Flask
from flask import Flask, request, jsonify #reply json file as output

app = Flask(__name__) 

def init_db():
    conn = sqlite3.connect('store_global_db')
    cursor = conn.cursor()
    
    #Create employees table
    cursor.execute('''CREATE TABLE IF NOT EXISTS tb_employees (
                         id INTEGER,
                         employer TEXT,
                         hire_date TEXT,
                         dep_id INTEGER,
                         job_id INTEGER
                     )''')
 
    #Create departaments table
    cursor.execute('''CREATE TABLE IF NOT EXISTS tb_departaments (
                         id INTEGER ,
                         departament TEXT
                     )''')

    #Create jobs table
    cursor.execute('''CREATE TABLE IF NOT EXISTS tb_jobs (
                         id INTEGER,
                         job TEXT
                     )''')
    conn.commit()
    conn.close()

@app.route('/upload_emp', methods=['POST'])
def upload_emp():
    file = request.files['file']
    df = pd.read_csv(file, delimiter=',' ,header = None, names=['id','employer','hire_date','dep_id','job_id'])
    
    total = len(df)
    #limit of inserts per one request
    max_limit = 1000 
    
    conn = sqlite3.connect('store_global_db')
        
    for start in range(0, total, max_limit):
        end = start + max_limit 
        batch_df = df[start:end] #slice df for each 1000 rows. 
        #append: If table exists, insert data. Create if does not exist.
        batch_df.to_sql('tb_employees', conn, if_exists='append', index=False)

    conn.commit()
    conn.close()

    response = {"Employees inserted":total}
    return jsonify(response)

@app.route('/upload_job', methods=['POST'])
def upload_job():
    file = request.files['file']
    df = pd.read_csv(file, delimiter=',' ,header = None, names=['id','job'])
    
    total = len(df)
    
    conn = sqlite3.connect('store_global_db')
    #replace: If table exists, drop it, recreate it, and insert data.
    df.to_sql('tb_jobs', conn, if_exists='replace', index=False)
    #conn.commit()
    conn.close()

    response = {"Jobs inserted":total}
    return jsonify(response)

@app.route('/upload_dep', methods=['POST'])
def upload_dep():
    file = request.files['file']
    df = pd.read_csv(file, delimiter=',' ,header = None, names=['id','departament'])
    
    total = len(df)
    
    conn = sqlite3.connect('store_global_db')
    #replace: If table exists, drop it, recreate it, and insert data.
    df.to_sql('tb_departaments', conn, if_exists='replace', index=False)
    #conn.commit()
    conn.close()

    response = {"Departaments inserted":total}
    return jsonify(response)



@app.route('/')
def index():
    return 'On line'

if __name__ == "__main__":
    
    #os.getcwd()

    init_db()
    app.run(debug=True, use_reloader=False) #disable the reloader to call app.run from Jupyter/Spyder
    #%tb
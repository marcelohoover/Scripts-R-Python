--Number of employees hired for each job and department in 2021 divided by quarter. The
--table must be ordered alphabetically by department and job.
WITH report as (
	select e.id,
		e.employer,
		datetime(hire_date) as hire_date,
		d.departament,
		j.job,
		case strftime('%m', datetime(hire_date)) 
			when '01' || '02' || '03' then 1 
			ELSE 0
			end as 	Q1,
		case strftime('%m', datetime(hire_date)) 
			when '04' || '05' || '06' then 1 
			ELSE 0
			end as 	Q2,
		case strftime('%m', datetime(hire_date)) 
			when '07' || '08' || '09' then 1 
			ELSE 0
			end as 	Q3,
		case strftime('%m', datetime(hire_date)) 
			when '10' || '11' || '12' then 1   
			ELSE 0
			end as 	Q4
		from tb_employees e
		left join tb_departaments d on d.id = e.dep_id
		left join tb_jobs j on j.id = e.job_id
		where datetime(hire_date) > '2020-12-31T00:00:00Z' and datetime(hire_date) < '2022-01-01T00:00:00Z' 
		)
select departament, job, sum(Q1) AS Q1, sum(Q2) AS Q2 , sum(Q3) AS Q3, sum(Q4) AS Q4 from report
GROUP BY departament, job
ORDER BY departament, job

-- List of ids, name and number of employees hired of each department that hired more
-- employees than the mean of employees hired in 2021 for all the departments, ordered
-- by the number of employees hired (descending).
-- he mean of employees hired in 2021 for all the departments is 278.3333333
WITH report2 as (
select  strftime('%Y', datetime(e.hire_date)) as year, e.dep_id, d.departament, count(*) as total_hired 
from tb_employees e left join tb_departaments d on d.id = e.dep_id
WHERE strftime('%Y', datetime(e.hire_date)) IS NOT NULL and dep_id is NOT NULL 
GROUP by strftime('%Y', datetime(e.hire_date)), e.dep_id, d.departament
)
select dep_id as id, departament, total_hired from report2 
where total_hired > (select avg(total_hired) as mean_employees_hired from report2 where year = '2021') 
order by total_hired desc


Globant’s Data Engineering Coding Challenge

Python 3.10.15
Pandas 2.2.3
Flask 3.1.0
sqlite3 3.45.3
requests 2.32.3
import boto3 
import pyspark
import pydeequ
import awswrangler as wr # es una libraria para usar PANDAS con otras tecnologias para facilitar y abstrair la escritura en S3
from pyspark.sql import SparkSession, SQLContext, Row
from pyspark.sql.functions import col, lit
from pydeequ.analyzers import *
from pydeequ.profiles import *
from pydeequ.checks import *
from pydeequ.verification import *
from pydeequ.suggestions import *

# Session
spark = (SparkSession
    .builder
    .config("spark.jars.packages", pydeequ.deequ_maven_coord)
    .config("spark.jars.excludes", pydeequ.f2j_maven_coord)
    .getOrCreate())
    

# Conf pyspark
conf = pyspark.SparkConf()
sc = pyspark.SparkContext.getOrCreate(conf=conf)
sqlContext = SQLContext(sc)


# Carga S3 Beneficiarios
df_s3 = sqlContext.read.options(delimiter=';' , header='True').csv(f's3://poc-bice-vida-deequ/beneficiarios/ifrs17_previsionales_beneficiario.csv')

check = Check(spark, CheckLevel.Error, "Review Check")
#df_s3.select('numorden').distinct().show()
#df_s3.printSchema()

#Check Beneficiarios
#AnalysisResult
analysisResult = AnalysisRunner(spark) \
                    .onData(df_s3) \
                    .addAnalyzer(Size()) \
                    .addAnalyzer(Completeness("nombre")) \
                    .addAnalyzer(ApproxCountDistinct("nombre")) \
                    .addAnalyzer(Completeness("apellidomaterno")) \
                    .addAnalyzer(ApproxCountDistinct("apellidomaterno")) \
                    .addAnalyzer(Completeness("apellidopaterno")) \
                    .addAnalyzer(ApproxCountDistinct("apellidopaterno")) \
                    .addAnalyzer(Completeness("pensionpersona")) \
                    .addAnalyzer(ApproxCountDistinct("pensionpersona")) \
                    .addAnalyzer(Completeness("relacionhijomadre")) \
                    .addAnalyzer(ApproxCountDistinct("relacionhijomadre")) \
                    .addAnalyzer(Completeness("situacioninvalidez")) \
                    .addAnalyzer(ApproxCountDistinct("situacioninvalidez")) \
                    .addAnalyzer(Completeness("derechoacrecer")) \
                    .addAnalyzer(ApproxCountDistinct("derechoacrecer")) \
                    .addAnalyzer(Completeness("derechopension")) \
                    .addAnalyzer(ApproxCountDistinct("derechopension")) \
                    .addAnalyzer(Completeness("rutbeneficiario")) \
                    .addAnalyzer(ApproxCountDistinct("rutbeneficiario")) \
                    .addAnalyzer(Completeness("dvrutbeneficiario")) \
                    .addAnalyzer(ApproxCountDistinct("dvrutbeneficiario")) \
                    .addAnalyzer(Completeness("numpoliza")) \
                    .addAnalyzer(ApproxCountDistinct("numpoliza")) \
                    .addAnalyzer(Completeness("numorden")) \
                    .addAnalyzer(ApproxCountDistinct("numorden")) \
                    .addAnalyzer(Completeness("sexo")) \
                    .addAnalyzer(ApproxCountDistinct("sexo")) \
                    .addAnalyzer(Completeness("requisitopension")) \
                    .addAnalyzer(ApproxCountDistinct("requisitopension")) \
                    .addAnalyzer(Completeness("tipobeneficiario")) \
                    .addAnalyzer(ApproxCountDistinct("tipobeneficiario")) \
                    .addAnalyzer(Completeness("fechanacimiento")) \
                    .addAnalyzer(ApproxCountDistinct("fechanacimiento")) \
                    .addAnalyzer(Completeness("fechainvalidez")) \
                    .addAnalyzer(ApproxCountDistinct("fechainvalidez")) \
                    .addAnalyzer(Completeness("fechafallecimiento")) \
                    .addAnalyzer(ApproxCountDistinct("fechafallecimiento")) \
                    .addAnalyzer(Completeness("fechanacimientohijomenor")) \
                    .addAnalyzer(ApproxCountDistinct("fechanacimientohijomenor")) \
                    .run()

analysisResult_df_s3 = AnalyzerContext.successMetricsAsDataFrame(spark, analysisResult)

df_analysisResult_df_s3 = analysisResult_df_s3.toPandas() # para dataset pequeños. en caso sea muy grande, continuar con SPARK

# Paso 01 add en glue job em configurações > Non-overrideable Job parameters
# clave --additional-python-modules
# valor pyarrow==2,awswrangler

# Etiquetas para la tabla beneficiarios AnalyzerResults
param = {
    "source": "IFRS17 - Beneficiarios AnalyzerResults",
    "class": "DQ en Deequ"
}

# Etiqueta para las columnas de la tabla beneficiarios
comments = {
    "entity": "Tipo de objecto (tablas or columns)",
    "instance": "Nombre de la entidad",
    "name": "Nombre del analyzer (metodo)",
    "value": "Resultado de analyzer (percentaje)"
}

res = wr.s3.to_parquet(
    df=df_analysisResult_df_s3,
    path=f"s3://poc-bice-vida-deequ/beneficiarios/ifrs17_previsionales_beneficiario_Analysis/",
    dataset=True,
    database="poc-bice-vida-deequ-database",
    table="beneficiarios_analisis", #La crea caso no exciste (de acuerdo con los grants de lake formation)
    mode="overwrite", # apend / overwrite partition
    description="Tabla de beneficiarios IFRS17 Bice - POC Bice Vida Calidad de datos - Analyzer Results en Deequ",
    parameters=param,
    columns_comments = comments
)

#analysisResult_df_s3.repartition(1).write.csv("s3://poc-bice-vida-deequ/beneficiarios/ifrs17_previsionales_beneficiario_Analysis", sep=';')


#VerificationSuite
checkResult = VerificationSuite(spark) \
    .onData(df_s3) \
    .addCheck(
        check \
        .isNonNegative("rutbeneficiario") \
        .isNonNegative("pensionpersona") \
        .isNonNegative("relacionhijomadre") \
        .isNonNegative("numpoliza") \
        .isNonNegative("numorden") \
        .isContainedIn("situacioninvalidez", ['N', 'T', 'P']) \
        .isContainedIn("derechoacrecer", ['N', 'S']) \
        .isContainedIn("derechopension", ['99', '10', '20']) \
        .isContainedIn("dvrutbeneficiario", ['0','1', '2', '3', '4', '5', '6', '7', '8', '9', 'K']) \
        .isContainedIn("requisitopension", ['1', '2', '3', '4', '5', '6', '7', '8', '9']) \
        .isContainedIn("sexo", ['M', 'F']) \
        .hasPattern(column = "sexo", pattern = r'^M?$|^F?$', assertion = lambda x : x >= 0.9) \
        .hasPattern("apellidomaterno", r'^[A-Za-z\s\#]+$', lambda x : x == 1.0 ) \
        .hasPattern("apellidopaterno", r'^[A-Za-z\s\#]+$', lambda x : x == 1.0) \
        .hasPattern("nombre", r'^[A-Za-z\s\#]+$', lambda x : x == 1.0) \
        .hasPattern("fechanacimiento",r'^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$|^NULL$', lambda x : x == 1.0) \
        .satisfies("fechainvalidez >= '1900-01-01' or fechainvalidez is null", "fechainvalidez", lambda x: x == 1.0) \
        .satisfies("fechafallecimiento >= '1900-01-01' or fechafallecimiento is null", "fechafallecimiento", lambda x: x == 1.0) \
        .satisfies("fechanacimientohijomenor >= '1900-01-01' or fechanacimientohijomenor is null", "fechanacimientohijomenor", lambda x: x == 1.0) \
        .isContainedIn("tipobeneficiario", ['99', '10', '11', '20', '21', '30', '35', '41', '42', '50', '51', '77'])) \
    .run()
val_df_s3 = VerificationResult.checkResultsAsDataFrame(spark, checkResult)
#val_df_s3.show()


df_VerificationResult_df_s3 = val_df_s3.toPandas() # para dataset pequeños. en caso sea muy grande, continuar con SPARK


# Etiquetas para la tabla beneficiarios VerificationResults
param_verification = {
    "source": "IFRS17 - Beneficiarios VerificationResults",
    "class": "DQ en Deequ"
}

# Etiqueta para las columnas de la tabla beneficiarios
comments_verification = {
    "check": "Tipo de Review",
    "check_level": "Level of Review",
    "check_status": "Status of Review",
    "constraint": "Prueba aplicada al tipo de dato",
    "constraint_status": "Resultado de la prueba",
    "constraint_message": "Percentaje de registros en complaince con la regla"    
}

res = wr.s3.to_parquet(
    df=df_VerificationResult_df_s3,
    path=f"s3://poc-bice-vida-deequ/beneficiarios/ifrs17_previsionales_beneficiario_Verification/",
    dataset=True,
    database="poc-bice-vida-deequ-database",
    table="beneficiarios_verification", #La crea caso no exciste (de acuerdo con los grants de lake formation)
    mode="overwrite", # apend / overwrite partition
    description="Tabla de beneficiarios IFRS17 Bice - POC Bice Vida Calidad de datos - Verification Results en Deequ",
    parameters=param_verification,
    columns_comments = comments_verification

)


'''
#df_s3.createOrReplaceTempView('tabla')
#spark.sql('select fechainvalidez from tabla where fechainvalidez is null ').show(19)

'''
# Close gateway or glue is never gonna finish 'till timeout
spark.sparkContext._gateway.close()

#val_df_s3.repartition(1).write.csv("s3a://poc-bice-vida-deequ/beneficiarios/ifrs17_previsionales_beneficiario_Verification", sep=';')

